from fastapi import APIRouter
from models.schemas import BpUploadRequest
from service.bp_service import upload_blood_pressure
from utils.result import success, fail

router = APIRouter()

@router.post("/api/device/upload")
def upload_bp(req: BpUploadRequest):
    if req.systolic <= 0 or req.diastolic <= 0:
        return fail("血压数据无效")
    ok = upload_blood_pressure(req.user_id, req.systolic, req.diastolic, req.heart_rate)
    return success("上传成功") if ok else fail("上传失败")