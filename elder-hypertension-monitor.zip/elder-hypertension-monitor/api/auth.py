from fastapi import APIRouter
from models.schemas import LoginRequest
from service.auth_service import user_login
from utils.result import success, fail

router = APIRouter()

@router.post("/api/auth/login")
def login(req: LoginRequest):
    res = user_login(req.account, req.password)
    if res:
        return success(res)
    return fail("账号或密码错误")