def push_warning(user_id: int, level: str):
    print(f"\n【预警推送】用户={user_id} 等级={level}")
    print("已推送给：老人、家属、医护、社区\n")