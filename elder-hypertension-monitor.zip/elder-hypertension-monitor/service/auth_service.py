import bcrypt
from utils.db import get_db_connection
from utils.jwt_util import create_token

def user_login(account: str, password: str):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM user WHERE account=%s", (account,))
        user = cursor.fetchone()
        if not user:
            return None
        if bcrypt.checkpw(password.encode(), user["password"].encode()):
            token = create_token(user["id"], user["role_code"])
            return {"token": token, "role": user["role_code"], "name": user["name"], "user_id": user["id"]}
        return None
    finally:
        cursor.close()
        conn.close()