from utils.db import get_db_connection
from service.push_service import push_warning

def upload_blood_pressure(user_id, systolic, diastolic, heart_rate):
    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            INSERT INTO bp_record (user_id, systolic, diastolic, heart_rate)
            VALUES (%s,%s,%s,%s)
        """, (user_id, systolic, diastolic, heart_rate))
        bp_id = cursor.lastrowid

        level = "NORMAL"
        if systolic >= 180 or diastolic >= 110:
            level = "EMERGENCY"
        elif systolic >= 160 or diastolic >= 100:
            level = "WARNING"
        elif systolic >= 140 or diastolic >= 90:
            level = "NOTICE"

        if level != "NORMAL":
            cursor.execute("""
                INSERT INTO warning_record (user_id, warn_level, bp_record_id)
                VALUES (%s,%s,%s)
            """, (user_id, level, bp_id))
            push_warning(user_id, level)
        conn.commit()
        return True
    except:
        return False
    finally:
        cursor.close()
        conn.close()