from pydantic import BaseModel

class LoginRequest(BaseModel):
    account: str
    password: str

class BpUploadRequest(BaseModel):
    user_id: int
    systolic: int
    diastolic: int
    heart_rate: int