from fastapi import FastAPI
from api.auth import router as auth_router
from api.device import router as device_router

app = FastAPI(
    title="居家智慧养老高血压监测系统",
    description="Python+FastAPI+MySQL 智能预警监测平台",
    version="1.0.0"
)

app.include_router(auth_router)
app.include_router(device_router)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)