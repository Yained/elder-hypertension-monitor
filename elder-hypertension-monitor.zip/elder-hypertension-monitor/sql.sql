CREATE DATABASE IF NOT EXISTS elder_health;
USE elder_health;

CREATE TABLE `user` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `account` VARCHAR(50) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `name` VARCHAR(50),
  `role_code` VARCHAR(20),
  `phone` VARCHAR(20)
);

CREATE TABLE `bp_record` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `user_id` INT,
  `systolic` INT,
  `diastolic` INT,
  `heart_rate` INT,
  `create_time` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE `warning_record` (
  `id` INT PRIMARY KEY AUTO_INCREMENT,
  `user_id` INT,
  `warn_level` VARCHAR(20),
  `bp_record_id` INT,
  `create_time` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO `user` (account, password, name, role_code)
VALUES ('test001', '$2b$12$ZJzn3CnrNnH4d.n8d0yGVOrKzJ5GdN8tQaGdN8tQaGdN8tQaGdN8tQ', '测试老人', 'ELDER');