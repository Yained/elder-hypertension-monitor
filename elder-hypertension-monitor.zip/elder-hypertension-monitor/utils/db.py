import pymysql
from pymysql.cursors import DictCursor

def get_db_connection():
    return pymysql.connect(
        host="localhost",
        user="root",
        password="root",
        database="elder_health",
        charset="utf8mb4",
        cursorclass=DictCursor
    )