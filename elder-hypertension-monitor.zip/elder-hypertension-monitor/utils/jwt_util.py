import jwt
import time

SECRET_KEY = "PYTHON_ELDER_HEALTH_2026"
ALGORITHM = "HS256"

def create_token(user_id: int, role_code: str):
    payload = {
        "user_id": user_id,
        "role_code": role_code,
        "exp": time.time() + 7*86400
    }
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)