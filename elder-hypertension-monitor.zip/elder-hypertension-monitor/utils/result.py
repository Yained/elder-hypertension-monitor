def success(data=None):
    return {"code":200, "msg":"成功", "data":data}

def fail(msg="失败"):
    return {"code":500, "msg":msg, "data":None}