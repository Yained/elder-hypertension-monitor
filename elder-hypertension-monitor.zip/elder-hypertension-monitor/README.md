# 居家智慧养老高血压动态监测系统
适用于老年群体的实时血压监测、智能风险预警、多端联动守护系统

## 技术栈
- Python 3.9+
- FastAPI
- MySQL
- JWT 权限认证
- 智能预警算法

## 功能
- 血压数据采集上传
- 三级智能预警
- 家属/医护/社区联动推送
- 老年用户权限体系

## 启动
pip install -r requirements.txt
python main.py

